let download=[
  {
    id:'1',
    Name:'Calender 2081',
    location:'../assects/images/2081/calinder_2081.zip',
    downloadName:'calinder2081.zip',
  },
  {
    id:'1',
    Name:'Calender 2080',
    location:'../assects/images/2080/calinder_2080.zip',
    downloadName:'calinder2080.zip',
  },
  {
    id:'1',
    Name:'Calender 2079',
    location:'../assects/images/2079/calinder_2079.zip',
    downloadName:'calinder2079.zip',
  },
  {
    id:'1',
    Name:'Calender 2078',
    location:'../assects/images/2078/calinder_2078.zip',
    downloadName:'calinder2078.zip',
  },
  {
    id:'1',
    Name:'Calender 2077',
    location:'../assects/images/2077/calinder_2077.zip',
    downloadName:'calinder2077.zip',
  },
]