let bod=[
  {
    id:'1',
    image:"../assects/structuremember/bod/chairperson.jpg",
    name:'Ramita Kc',
    post:"ChairPerson",
  },
  {
    id:'2',
    image:"../assects/structuremember/bod/vice-chairperson.jpg",
    name:'Kunti Bhandari',
    post:"Vice-ChairPerson",
  },
  {
    id:'3',
    image:"../assects/structuremember/bod/secreaty.jpg",
    name:'Kamlesh Thapa Khadka',
    post:"Secretary",
  },
  {
    id:'4',
    image:"../assects/structuremember/bod/treasurer.jpg",
    name:'Manju Thapa',
    post:"Treasurer",
  },
  {
    id:'5',
    image:"../assects/structuremember/bod/BoardMember1.jpg",
    name:'Kamala Kumari Bista',
    post:"Board Member",
  },
  {
    id:'6',
    image:"../assects/structuremember/bod/BoardMember2.jpg",
    name:'Durga Thapa',
    post:"Board Member",
  },
  {
    id:'7',
    image:"../assects/structuremember/bod/BoardMember3.jpg",
    name:'Sanu Basnet',
    post:"Board Member",
  },
]


let asc=[
  {
    id:'1',
    image:"../assects/structuremember/acccom/coordinator.jpg",
    name:'Sarala Sahi',
    post:"Coordinator",
  },
  {
    id:'2',
    image:"../assects/structuremember/acccom/member1.jpg",
    name:'Rupak Luitel',
    post:"Member",
  },
  {
    id:'3',
    image:"../assects/structuremember/acccom/member2.png",
    name:'Ramesh Khadka',
    post:"Member",
  },
]

let lc=[
  {
    id:'1',
    image:"../assects/structuremember/loancom/coordinator.jpg",
    name:'Durga Thapa',
    post:"Coordinator",
  },
  {
    id:'2',
    image:"../assects/structuremember/loancom/member1.jpg",
    name:'Kabindra lama',
    post:"Member",
  },
  {
    id:'3',
    image:"../assects/structuremember/loancom/member2.jpg",
    name:'Sita Bista',
    post:"Member",
  },
]
let ec=[
  {
    id:'1',
    image:"../assects/structuremember/educom/coordinator.jpg",
    name:'Rajendra Basnet',
    post:"Coordinator",
  },
  {
    id:'2',
    image:"../assects/structuremember/educom/member1.jpg",
    name:'Bharat Karki',
    post:"Member",
  },
  {
    id:'3',
    image:"../assects/structuremember/educom/member2.jpg",
    name:'JayKrishna Giri',
    post:"Member",
  },
]


let managementTeam=[
  {
    id:'1',
    image:"../assects/structuremember/managementTeam/mgmt1.jpg",
    name:'Sunita Kunwar Basnet',
    post:"Office Incharge",
  },
  {
    id:'2',
    image:"../assects/structuremember/managementTeam/mgmt2.jpg",
    name:'Jeevan Khatiwada ',
    post:"Acountant",
  },
  {
    id:'3',
    image:"../assects/structuremember/managementTeam/mgmt3.jpg",
    name:'Suryakala K.C.',
    post:"Acountant",
  },
  {
    id:'4',
    image:"../assects/structuremember/managementTeam/mgmt4.jpg",
    name:'Anita Thapa',
    post:"Acountant",
  },
  {
    id:'5',
    image:"../assects/structuremember/managementTeam/mgmt5.jpg",
    name:'Sabina Bogati',
    post:"Acountant",
  },
]