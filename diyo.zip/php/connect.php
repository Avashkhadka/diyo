<?php
$conn=mysqli_connect("localhost","root","","contactmsg");
  if (!$conn) {
    echo "Failed connection: " . mysqli_connect_error();
} else {
    echo "";
}

?>

